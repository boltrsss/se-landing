(function(){
  var img = document.createElement('img');
  var referrer = document.referrer;
  img.src = '//two.eagermint.com/view?referref=' + referrer;
  img.alt = '';
  img.style.cssText = 'position:absolute; top=-9999px; width:1px; height:1px; border:0';
})();
